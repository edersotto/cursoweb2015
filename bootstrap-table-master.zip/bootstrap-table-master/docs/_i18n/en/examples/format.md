# Format []({{ site.repo }}/blob/master/docs/_i18n/{{ site.lang }}/examples/format.md)

Use `formatter` column option to format the display of bootstrap table column. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="300" data-src="http://jsfiddle.net/wenyi/e3nk137y/21/embedded/html,js,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>